# Crop-Yield-Prediction
Prediction of the yield of the crop in an area in the basis of different factors
https://youtu.be/6_cVUI5eIk4
